# Vinyl Deck

An in-game music player for **Minecraft 1.21.1 / NeoForge**: load your own music, browse it by albums,
artists and tracks, keep favorites, and control playback from a polished dark UI.

## Features
- Own music library: `.minecraft/musicplayer/library/` (subfolders become albums when tags are missing)
- **Drag & drop** MP3 / OGG / WAV files or folders onto the player window
- ID3 tags (title, artist, album, year, track no.) and embedded cover art; `cover.jpg` / `folder.png` in an album folder also works
- Views: Albums (cover grid), Artists, Tracks, Favorites; search; sorting (title / artist / album / year / recent)
- Album page with Play / Shuffle, queue, shuffle, repeat (off / all / one), seek bar, volume, mini level visualizer
- UI accent color follows the cover of the playing album
- Portable Player item (right-click) + hotkey `M`; unbound keys for play/pause, next, previous
- Client-side only playback (files never leave your computer)

## Build
```
gradle wrapper --gradle-version 8.10   # once, or copy the wrapper from the official NeoForge MDK
./gradlew runClient
./gradlew build                         # jar in build/libs
```
Check `neo_version` in `gradle.properties` and the `net.neoforged.moddev` plugin version in `build.gradle`
against the official NeoForge 1.21.1 MDK, and bump them to the latest if needed.

MP3 decoding uses [JLayer](https://github.com/umjammer/jlayer) (LGPL), copied into the mod jar at build time.
OGG decoding uses Minecraft's own Vorbis decoder, WAV uses Java Sound.

## Roadmap ideas
Jukebox block with positional audio, cassette items, FLAC support, Vorbis comment tags for OGG,
playlists, equalizer, sharing a track with other players on a server.
