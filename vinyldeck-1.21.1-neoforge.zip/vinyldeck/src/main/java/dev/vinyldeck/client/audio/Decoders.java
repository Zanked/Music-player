package dev.vinyldeck.client.audio;

import com.mojang.blaze3d.audio.OggAudioStream;
import dev.vinyldeck.client.library.Library;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.DecoderException;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.decoder.SampleBuffer;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Opens MP3 (JLayer), OGG (Minecraft's own Vorbis decoder) and WAV (Java Sound) as PCM streams. */
public final class Decoders {
    private Decoders() {}

    public static PcmSource open(Path p, long startMs) throws IOException {
        PcmSource s = switch (Library.ext(p)) {
            case "mp3" -> new Mp3Source(p);
            case "ogg" -> new OggSource(p);
            case "wav" -> new WavSource(p);
            default -> throw new IOException("Unsupported format: " + p.getFileName());
        };
        if (startMs > 0) skip(s, startMs);
        return s;
    }

    public static long durationMs(Path p) {
        try {
            return switch (Library.ext(p)) {
                case "mp3" -> mp3Duration(p);
                case "ogg" -> OggInfo.durationMs(p);
                case "wav" -> {
                    AudioFileFormat aff = AudioSystem.getAudioFileFormat(p.toFile());
                    long frames = aff.getFrameLength();
                    float rate = aff.getFormat().getFrameRate();
                    yield frames > 0 && rate > 0 ? (long) (frames * 1000.0 / rate) : 0;
                }
                default -> 0;
            };
        } catch (Exception e) {
            return 0;
        }
    }

    private static long mp3Duration(Path p) throws Exception {
        try (InputStream in = Files.newInputStream(p)) {
            Bitstream bs = new Bitstream(in);
            Header h = bs.readFrame();
            return h == null ? 0 : (long) h.total_ms((int) Files.size(p));
        }
    }

    private static void skip(PcmSource s, long ms) throws IOException {
        AudioFormat f = s.format();
        long bytes = (long) (ms / 1000.0 * f.getFrameRate()) * f.getFrameSize();
        byte[] tmp = new byte[16384];
        while (bytes > 0) {
            int n = s.read(tmp, 0, (int) Math.min(tmp.length, bytes));
            if (n < 0) break;
            bytes -= n;
        }
    }

    // ------------------------------------------------------------------ MP3

    private static final class Mp3Source implements PcmSource {
        private final Bitstream bs;
        private final Decoder decoder = new Decoder();
        private AudioFormat fmt;
        private byte[] pending = new byte[8192];
        private int pendLen, pendPos;

        Mp3Source(Path p) throws IOException {
            bs = new Bitstream(new BufferedInputStream(Files.newInputStream(p), 1 << 16));
            try {
                if (!fill()) throw new IOException("No MP3 frames in " + p.getFileName());
            } catch (JavaLayerException e) {
                throw new IOException(e);
            }
        }

        private boolean fill() throws JavaLayerException {
            for (int attempt = 0; attempt < 64; attempt++) {
                Header h = bs.readFrame();
                if (h == null) return false;
                try {
                    SampleBuffer out = (SampleBuffer) decoder.decodeFrame(h, bs);
                    if (fmt == null) {
                        fmt = new AudioFormat(out.getSampleFrequency(), 16, out.getChannelCount(), true, false);
                    }
                    short[] s = out.getBuffer();
                    int n = out.getBufferLength();
                    if (pending.length < n * 2) pending = new byte[n * 2];
                    for (int i = 0; i < n; i++) {
                        pending[2 * i] = (byte) s[i];
                        pending[2 * i + 1] = (byte) (s[i] >> 8);
                    }
                    pendLen = n * 2;
                    pendPos = 0;
                    return true;
                } catch (DecoderException broken) {
                    // skip a corrupt frame and try the next one
                } finally {
                    bs.closeFrame();
                }
            }
            return false;
        }

        @Override public AudioFormat format() { return fmt; }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            int total = 0;
            while (total < len) {
                if (pendPos >= pendLen) {
                    try {
                        if (!fill()) break;
                    } catch (JavaLayerException e) {
                        throw new IOException(e);
                    }
                }
                int n = Math.min(len - total, pendLen - pendPos);
                System.arraycopy(pending, pendPos, b, off + total, n);
                pendPos += n;
                total += n;
            }
            return total == 0 ? -1 : total;
        }

        @Override
        public void close() throws IOException {
            try {
                bs.close();
            } catch (JavaLayerException e) {
                throw new IOException(e);
            }
        }
    }

    // ------------------------------------------------------------------ OGG

    private static final class OggSource implements PcmSource {
        private final OggAudioStream stream;
        private final AudioFormat fmt;
        private ByteBuffer cur;

        OggSource(Path p) throws IOException {
            stream = new OggAudioStream(new BufferedInputStream(Files.newInputStream(p), 1 << 16));
            fmt = stream.getFormat();
        }

        @Override public AudioFormat format() { return fmt; }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            int total = 0;
            while (total < len) {
                if (cur == null || !cur.hasRemaining()) {
                    cur = stream.read(8192);
                    if (cur == null || !cur.hasRemaining()) break;
                }
                int n = Math.min(len - total, cur.remaining());
                cur.get(b, off + total, n);
                total += n;
            }
            return total == 0 ? -1 : total;
        }

        @Override public void close() throws IOException { stream.close(); }
    }

    // ------------------------------------------------------------------ WAV

    private static final class WavSource implements PcmSource {
        private final AudioInputStream in;

        WavSource(Path p) throws IOException {
            try {
                AudioInputStream raw = AudioSystem.getAudioInputStream(p.toFile());
                AudioFormat base = raw.getFormat();
                int ch = base.getChannels();
                AudioFormat target = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED,
                        base.getSampleRate(), 16, ch, ch * 2, base.getSampleRate(), false);
                in = AudioSystem.getAudioInputStream(target, raw);
            } catch (javax.sound.sampled.UnsupportedAudioFileException e) {
                throw new IOException(e);
            }
        }

        @Override public AudioFormat format() { return in.getFormat(); }

        @Override public int read(byte[] b, int off, int len) throws IOException { return in.read(b, off, len); }

        @Override public void close() throws IOException { in.close(); }
    }
}
