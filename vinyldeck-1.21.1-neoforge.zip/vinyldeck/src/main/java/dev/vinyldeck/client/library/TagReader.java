package dev.vinyldeck.client.library;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

/** Minimal ID3v2.3/2.4 reader: title, artist, album, year, track number, embedded cover. */
public final class TagReader {
    public record Meta(String title, String artist, String album, int year, int trackNo, byte[] cover) {}

    public static final Meta EMPTY = new Meta("", "", "", 0, 0, null);

    private TagReader() {}

    public static Meta readId3(Path file) {
        try (InputStream in = new BufferedInputStream(Files.newInputStream(file))) {
            byte[] h = in.readNBytes(10);
            if (h.length < 10 || h[0] != 'I' || h[1] != 'D' || h[2] != '3') return EMPTY;
            int ver = h[3] & 0xFF;
            if (ver != 3 && ver != 4) return EMPTY;
            int size = synchsafe(h, 6);
            if (size <= 0 || size > 24 * 1024 * 1024) return EMPTY;
            byte[] d = in.readNBytes(size);

            int pos = 0;
            if ((h[5] & 0x40) != 0 && d.length >= 4) {
                pos = ver == 4 ? synchsafe(d, 0) : int32(d, 0) + 4;
            }
            String title = "", artist = "", album = "";
            int year = 0, track = 0;
            byte[] cover = null;

            while (pos + 10 <= d.length) {
                if (d[pos] == 0) break;
                String id = new String(d, pos, 4, StandardCharsets.ISO_8859_1);
                int fs = ver == 4 ? synchsafe(d, pos + 4) : int32(d, pos + 4);
                int start = pos + 10;
                if (fs <= 0 || start + fs > d.length) break;
                switch (id) {
                    case "TIT2" -> title = text(d, start, fs);
                    case "TPE1" -> artist = text(d, start, fs);
                    case "TALB" -> album = text(d, start, fs);
                    case "TYER", "TDRC" -> { if (year == 0) year = leadingInt(text(d, start, fs)); }
                    case "TRCK" -> track = leadingInt(text(d, start, fs));
                    case "APIC" -> { if (cover == null) cover = picture(d, start, start + fs); }
                    default -> { }
                }
                pos = start + fs;
            }
            return new Meta(title, artist, album, year, track, cover);
        } catch (Exception e) {
            return EMPTY;
        }
    }

    private static String text(byte[] d, int off, int len) {
        if (len <= 1) return "";
        Charset cs = switch (d[off] & 0xFF) {
            case 0 -> StandardCharsets.ISO_8859_1;
            case 1 -> StandardCharsets.UTF_16;
            case 2 -> StandardCharsets.UTF_16BE;
            default -> StandardCharsets.UTF_8;
        };
        String s = new String(d, off + 1, len - 1, cs);
        int z = s.indexOf('\0');
        if (z >= 0) s = s.substring(0, z);
        return s.trim();
    }

    private static byte[] picture(byte[] d, int start, int end) {
        int enc = d[start] & 0xFF;
        int p = start + 1;
        while (p < end && d[p] != 0) p++;   // MIME type
        p += 2;                             // terminator + picture type
        if (enc == 1 || enc == 2) {
            while (p + 1 < end && !(d[p] == 0 && d[p + 1] == 0)) p += 2;
            p += 2;
        } else {
            while (p < end && d[p] != 0) p++;
            p += 1;
        }
        return p < end ? Arrays.copyOfRange(d, p, end) : null;
    }

    private static int leadingInt(String s) {
        int i = 0, v = 0;
        while (i < s.length() && Character.isDigit(s.charAt(i)) && i < 9) {
            v = v * 10 + (s.charAt(i) - '0');
            i++;
        }
        return v;
    }

    private static int synchsafe(byte[] b, int o) {
        return ((b[o] & 0x7F) << 21) | ((b[o + 1] & 0x7F) << 14) | ((b[o + 2] & 0x7F) << 7) | (b[o + 3] & 0x7F);
    }

    private static int int32(byte[] b, int o) {
        return ((b[o] & 0xFF) << 24) | ((b[o + 1] & 0xFF) << 16) | ((b[o + 2] & 0xFF) << 8) | (b[o + 3] & 0xFF);
    }
}
