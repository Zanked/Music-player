package dev.vinyldeck.client;

import dev.vinyldeck.client.gui.LibraryScreen;
import net.minecraft.client.Minecraft;

/** Client-only entry points called from common code (guarded by level.isClientSide). */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openLibrary() {
        Minecraft.getInstance().setScreen(new LibraryScreen());
    }
}
