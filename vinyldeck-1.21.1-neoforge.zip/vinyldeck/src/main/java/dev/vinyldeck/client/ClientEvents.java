package dev.vinyldeck.client;

import dev.vinyldeck.client.audio.AudioEngine;
import dev.vinyldeck.client.gui.LibraryScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundSource;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

public final class ClientEvents {
    private ClientEvents() {}

    public static void onTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        AudioEngine engine = AudioEngine.INSTANCE;
        engine.setExternalVolume(mc.options.getSoundSourceVolume(SoundSource.MASTER));

        while (VinylDeckClient.OPEN.consumeClick()) {
            if (mc.player != null && mc.screen == null) {
                mc.setScreen(new LibraryScreen());
            }
        }
        while (VinylDeckClient.PLAY_PAUSE.consumeClick()) engine.togglePause();
        while (VinylDeckClient.NEXT.consumeClick()) engine.next();
        while (VinylDeckClient.PREVIOUS.consumeClick()) engine.previous();
    }

    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        AudioEngine.INSTANCE.stop();
    }
}
