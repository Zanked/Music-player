package dev.vinyldeck.client.library;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public final class Album {
    public static final int COVER = 128;
    private static final AtomicInteger IDS = new AtomicInteger();

    public final String name;
    public final List<Track> tracks = new ArrayList<>();
    public String artist = "";
    public int year;
    public long addedAt;
    /** ARGB pixels, COVER x COVER, or null when the album has no artwork. */
    public int[] coverPixels;
    public int accent = 0xFF7C5CFF;

    private final int id = IDS.incrementAndGet();
    private ResourceLocation texture;
    private boolean textureTried;

    public Album(String name) {
        this.name = name;
    }

    public long totalMs() {
        long sum = 0;
        for (Track t : tracks) sum += t.durationMs;
        return sum;
    }

    /** Render thread only. Lazily uploads the cover to the GPU. */
    public ResourceLocation texture() {
        if (texture == null && coverPixels != null && !textureTried) {
            textureTried = true;
            try {
                NativeImage img = new NativeImage(COVER, COVER, false);
                for (int y = 0; y < COVER; y++) {
                    for (int x = 0; x < COVER; x++) {
                        int argb = coverPixels[y * COVER + x];
                        int a = argb >>> 24, r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
                        img.setPixelRGBA(x, y, (a << 24) | (b << 16) | (g << 8) | r);
                    }
                }
                DynamicTexture tex = new DynamicTexture(img);
                tex.setFilter(true, false);
                ResourceLocation rl = ResourceLocation.fromNamespaceAndPath("vinyldeck", "cover/" + id);
                Minecraft.getInstance().getTextureManager().register(rl, tex);
                texture = rl;
            } catch (Exception ignored) {
                texture = null;
            }
        }
        return texture;
    }

    /** Render thread only. */
    public void releaseTexture() {
        if (texture != null) {
            Minecraft.getInstance().getTextureManager().release(texture);
            texture = null;
        }
    }
}
