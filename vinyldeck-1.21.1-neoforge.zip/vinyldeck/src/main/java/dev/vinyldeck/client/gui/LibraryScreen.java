package dev.vinyldeck.client.gui;

import dev.vinyldeck.client.ClientConfig;
import dev.vinyldeck.client.VinylDeckClient;
import dev.vinyldeck.client.audio.AudioEngine;
import dev.vinyldeck.client.library.Album;
import dev.vinyldeck.client.library.Library;
import dev.vinyldeck.client.library.Track;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Path;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/** The Vinyl Deck window: sidebar, album grid / track lists, album page and the player bar. */
public class LibraryScreen extends Screen {
    private enum View {
        ALBUMS("albums"), ARTISTS("artists"), TRACKS("tracks"), FAVORITES("favorites");
        final String key;
        View(String key) { this.key = key; }
    }

    private enum Sort { TITLE, ARTIST, ALBUM, YEAR, RECENT }

    private record Hit(int x0, int y0, int x1, int y1, Runnable action) {}

    private static final int SIDE = 110, BAR = 56, HEAD = 30;

    private final AudioEngine engine = AudioEngine.INSTANCE;
    private final Library lib = Library.INSTANCE;
    private final List<Hit> hits = new ArrayList<>();
    private final float[] levels = new float[AudioEngine.LEVELS];

    private View view = View.ALBUMS;
    private Sort sort = Sort.TITLE;
    private String query = "";
    private String artistFilter;
    private Album openAlbum;
    private boolean dirty = true;
    private int libRev = -1;

    private List<Album> shownAlbums = List.of();
    private List<Track> shownTracks = List.of();
    private List<Track> detailTracks = List.of();
    private List<Map.Entry<String, Integer>> shownArtists = List.of();

    private int wx0, wy0, wx1, wy1, cx0, cy0, cx1, cy1, searchX;
    private float scrollTarget, scrollShown;
    private int maxScroll;
    private int accent = Ui.DEFAULT_ACCENT;
    private EditBox search;

    private int progX0, progX1, progY0, volX0, volX1, volY0;
    private boolean dragProgress, dragVolume;
    private float seekFrac;

    private String statusMsg = "";
    private long statusUntil;

    public LibraryScreen() {
        super(Component.translatable("gui.vinyldeck.title"));
    }

    // ------------------------------------------------------------------ setup

    @Override
    protected void init() {
        int w = Math.min(width - 16, 780), h = Math.min(height - 16, 440);
        wx0 = (width - w) / 2;
        wy0 = (height - h) / 2;
        wx1 = wx0 + w;
        wy1 = wy0 + h;
        cx0 = wx0 + SIDE + 2;
        cy0 = wy0 + HEAD;
        cx1 = wx1 - 4;
        cy1 = wy1 - BAR;
        searchX = wx1 - 10 - 100;

        search = new EditBox(font, searchX, wy0 + 11, 100, 12, Component.translatable("gui.vinyldeck.search"));
        search.setBordered(false);
        search.setMaxLength(48);
        search.setHint(Component.translatable("gui.vinyldeck.search").withStyle(ChatFormatting.DARK_GRAY));
        search.setResponder(s -> {
            query = s.toLowerCase(Locale.ROOT).trim();
            dirty = true;
            scrollTarget = 0;
        });
        search.setValue(query);
        addRenderableWidget(search);
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override public void renderBackground(GuiGraphics g, int mx, int my, float pt) { }

    private static String tr(String key, Object... args) {
        return Component.translatable("gui.vinyldeck." + key, args).getString();
    }

    // ------------------------------------------------------------------ data

    private boolean matches(String s) { return s.toLowerCase(Locale.ROOT).contains(query); }

    private void rebuild() {
        dirty = false;
        if (libRev != lib.revision()) {
            libRev = lib.revision();
            if (openAlbum != null) openAlbum = lib.findAlbum(openAlbum.name);
        }

        List<Album> albums = new ArrayList<>();
        for (Album a : lib.albums()) {
            if (artistFilter != null && a.tracks.stream().noneMatch(t -> t.artist.equalsIgnoreCase(artistFilter))) continue;
            if (!query.isEmpty() && !(matches(a.name) || matches(a.artist)
                    || a.tracks.stream().anyMatch(t -> matches(t.title)))) continue;
            albums.add(a);
        }
        albums.sort(albumOrder());
        shownAlbums = albums;

        List<Track> tracks = new ArrayList<>();
        for (Track t : lib.tracks()) {
            if (view == View.FAVORITES && !lib.isFavorite(t)) continue;
            if (!query.isEmpty() && !(matches(t.title) || matches(t.artist) || matches(t.album))) continue;
            tracks.add(t);
        }
        tracks.sort(trackOrder());
        shownTracks = tracks;

        Map<String, Integer> artists = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        for (Track t : lib.tracks()) {
            if (!query.isEmpty() && !matches(t.artist)) continue;
            artists.merge(t.artist, 1, Integer::sum);
        }
        List<Map.Entry<String, Integer>> artistList = new ArrayList<>();
        artists.forEach((k, v) -> artistList.add(new AbstractMap.SimpleEntry<>(k, v)));
        shownArtists = artistList;

        List<Track> detail = new ArrayList<>();
        if (openAlbum != null) {
            for (Track t : openAlbum.tracks) {
                if (query.isEmpty() || matches(t.title) || matches(t.artist)) detail.add(t);
            }
        }
        detailTracks = detail;
    }

    private Comparator<Album> albumOrder() {
        Comparator<Album> byName = Comparator.comparing((Album a) -> a.name, String.CASE_INSENSITIVE_ORDER);
        return switch (sort) {
            case ARTIST -> Comparator.comparing((Album a) -> a.artist, String.CASE_INSENSITIVE_ORDER).thenComparing(byName);
            case YEAR -> Comparator.comparingInt((Album a) -> a.year).reversed().thenComparing(byName);
            case RECENT -> Comparator.comparingLong((Album a) -> a.addedAt).reversed();
            default -> byName;
        };
    }

    private Comparator<Track> trackOrder() {
        Comparator<Track> byTitle = Comparator.comparing((Track t) -> t.title, String.CASE_INSENSITIVE_ORDER);
        Comparator<Track> byAlbum = Comparator.comparing((Track t) -> t.album, String.CASE_INSENSITIVE_ORDER)
                .thenComparingInt(t -> t.trackNo);
        return switch (sort) {
            case ARTIST -> Comparator.comparing((Track t) -> t.artist, String.CASE_INSENSITIVE_ORDER).thenComparing(byAlbum);
            case ALBUM -> byAlbum;
            case YEAR -> Comparator.comparingInt((Track t) -> t.year).reversed().thenComparing(byTitle);
            case RECENT -> Comparator.comparingLong((Track t) -> t.addedAt).reversed();
            default -> byTitle;
        };
    }

    // ------------------------------------------------------------------ actions

    private void setView(View v) {
        view = v;
        openAlbum = null;
        artistFilter = null;
        scrollTarget = scrollShown = 0;
        dirty = true;
    }

    private void openAlbum(Album a) {
        openAlbum = a;
        scrollTarget = scrollShown = 0;
        dirty = true;
    }

    private void closeAlbum() {
        openAlbum = null;
        scrollTarget = scrollShown = 0;
        dirty = true;
    }

    private void cycleSort() {
        Sort[] all = Sort.values();
        do {
            sort = all[(sort.ordinal() + 1) % all.length];
        } while (view == View.ALBUMS && sort == Sort.ALBUM);
        dirty = true;
    }

    private void playAlbum(Album a, boolean shuffle) {
        if (engine.shuffle() != shuffle) engine.toggleShuffle();
        List<Track> list = new ArrayList<>(a.tracks);
        engine.playQueue(list, shuffle ? new java.util.Random().nextInt(list.size()) : 0);
    }

    private void saveVolume() {
        try {
            ClientConfig.VOLUME.set((double) engine.volume());
            ClientConfig.SPEC.save();
        } catch (Exception ignored) {
            // config not loaded: not fatal
        }
    }

    private void hit(int x0, int y0, int x1, int y1, Runnable r) {
        hits.add(new Hit(x0, y0, x1, y1, r));
    }

    /** Hit rectangle for scrolled content: clipped to the visible content area. */
    private void hitC(int x0, int y0, int x1, int y1, Runnable r) {
        int a = Math.max(y0, cy0), b = Math.min(y1, cy1);
        if (a < b) hits.add(new Hit(x0, a, x1, b, r));
    }

    private boolean inContent(double mx, double my) { return Ui.in(mx, my, cx0, cy0, cx1, cy1); }

    private long currentDuration() {
        Track t = engine.current();
        return t == null ? 0 : t.durationMs;
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        if (dirty || libRev != lib.revision()) rebuild();
        hits.clear();

        Track cur = engine.current();
        int target = cur != null && cur.albumRef != null ? cur.albumRef.accent : Ui.DEFAULT_ACCENT;
        accent = Ui.mix(accent, target, 0.08f);
        scrollShown += (scrollTarget - scrollShown) * 0.35f;
        if (Math.abs(scrollTarget - scrollShown) < 0.5f) scrollShown = scrollTarget;

        g.fill(0, 0, width, height, 0xA0000000);
        Ui.rounded(g, wx0 - 1, wy0 - 1, wx1 + 1, wy1 + 1, 8, Ui.alpha(accent, 0x66));
        Ui.rounded(g, wx0, wy0, wx1, wy1, 7, Ui.BG);

        renderSidebar(g, mx, my);
        renderHeader(g, mx, my);
        renderContent(g, mx, my);
        renderBar(g, mx, my);
        search.render(g, mx, my, pt);
    }

    private void button(GuiGraphics g, int mx, int my, int x0, int y0, int x1, int y1,
                        String label, boolean primary, boolean scrolled, Runnable r) {
        boolean hov = Ui.in(mx, my, x0, y0, x1, y1) && (!scrolled || inContent(mx, my));
        int bg = primary ? (hov ? Ui.mix(accent, 0xFFFFFFFF, 0.2f) : accent) : (hov ? Ui.HOVER : Ui.CARD);
        Ui.rounded(g, x0, y0, x1, y1, 4, bg);
        g.drawString(font, label, (x0 + x1 - font.width(label)) / 2, (y0 + y1 - 8) / 2 + 1,
                primary ? Ui.BG : Ui.TEXT, false);
        if (scrolled) hitC(x0, y0, x1, y1, r);
        else hit(x0, y0, x1, y1, r);
    }

    // ---- sidebar ----

    private void renderSidebar(GuiGraphics g, int mx, int my) {
        int x0 = wx0 + 6, x1 = wx0 + SIDE - 2, y0 = wy0 + 6, y1 = wy1 - BAR - 2;
        Ui.rounded(g, x0, y0, x1, y1, 6, Ui.PANEL);
        g.drawString(font, Component.literal("♫ Vinyl Deck").withStyle(ChatFormatting.BOLD), x0 + 8, y0 + 8, accent, false);

        String[] icons = {"▣", "☺", "♪", "♥"};
        View[] views = View.values();
        for (int i = 0; i < views.length; i++) {
            View v = views[i];
            int ny = y0 + 28 + i * 21;
            boolean sel = view == v;
            boolean hov = Ui.in(mx, my, x0 + 4, ny, x1 - 4, ny + 19);
            if (sel || hov) Ui.rounded(g, x0 + 4, ny, x1 - 4, ny + 19, 4, sel ? Ui.alpha(accent, 0x3A) : Ui.HOVER);
            if (sel) g.fill(x0 + 4, ny + 4, x0 + 6, ny + 15, accent);
            g.drawString(font, Ui.clip(font, icons[i] + "  " + tr(v.key), x1 - x0 - 20), x0 + 12, ny + 6,
                    sel ? Ui.TEXT : Ui.MUTED, false);
            hit(x0 + 4, ny, x1 - 4, ny + 19, () -> setView(v));
        }

        String info = lib.scanning() ? tr("scanning") : tr("counts", lib.tracks().size(), lib.albums().size());
        g.drawString(font, Ui.clip(font, info, x1 - x0 - 12), x0 + 8, y1 - 62, Ui.MUTED, false);
        if (statusUntil > System.currentTimeMillis()) {
            g.drawString(font, Ui.clip(font, statusMsg, x1 - x0 - 12), x0 + 8, y1 - 74, accent, false);
        }
        button(g, mx, my, x0 + 6, y1 - 46, x1 - 6, y1 - 27, tr("open_folder"), false, false,
                () -> Util.getPlatform().openPath(lib.dir()));
        button(g, mx, my, x0 + 6, y1 - 24, x1 - 6, y1 - 6, tr("rescan"), false, false, lib::rescan);
    }

    // ---- header ----

    private void renderHeader(GuiGraphics g, int mx, int my) {
        int hx = cx0 + 10;
        int ty = wy0 + 11;
        if (openAlbum != null) {
            String back = "←  " + tr("back");
            boolean hov = Ui.in(mx, my, hx - 4, ty - 4, hx + font.width(back) + 4, ty + 12);
            g.drawString(font, back, hx, ty, hov ? Ui.TEXT : Ui.MUTED, false);
            hit(hx - 4, ty - 4, hx + font.width(back) + 4, ty + 12, this::closeAlbum);
        } else {
            Component title = Component.literal(tr(view.key)).withStyle(ChatFormatting.BOLD);
            g.drawString(font, title, hx, ty, Ui.TEXT, false);
            if (artistFilter != null) {
                int cxp = hx + font.width(title) + 10;
                String chip = Ui.clip(font, artistFilter, 90) + "  ✕";
                int cw = font.width(chip) + 12;
                boolean hov = Ui.in(mx, my, cxp, ty - 3, cxp + cw, ty + 11);
                Ui.rounded(g, cxp, ty - 3, cxp + cw, ty + 11, 6, hov ? Ui.alpha(accent, 0x55) : Ui.alpha(accent, 0x30));
                g.drawString(font, chip, cxp + 6, ty, Ui.TEXT, false);
                hit(cxp, ty - 3, cxp + cw, ty + 11, () -> { artistFilter = null; dirty = true; });
            }
        }

        Ui.rounded(g, searchX - 8, wy0 + 7, wx1 - 6, wy0 + 24, 8, Ui.CARD);

        if (openAlbum == null && view != View.ARTISTS) {
            String label = tr("sort") + ": " + tr("sort." + sort.name().toLowerCase(Locale.ROOT));
            int sw = font.width(label) + 14;
            int sx1 = searchX - 14, sx0 = sx1 - sw;
            boolean hov = Ui.in(mx, my, sx0, wy0 + 7, sx1, wy0 + 24);
            Ui.rounded(g, sx0, wy0 + 7, sx1, wy0 + 24, 8, hov ? Ui.HOVER : Ui.CARD);
            g.drawString(font, label, sx0 + 7, wy0 + 12, Ui.MUTED, false);
            hit(sx0, wy0 + 7, sx1, wy0 + 24, this::cycleSort);
        }
    }

    // ---- content ----

    private void renderContent(GuiGraphics g, int mx, int my) {
        g.enableScissor(cx0, cy0, cx1, cy1);
        int y0 = cy0 - (int) scrollShown;
        int contentH;

        if (openAlbum != null) {
            contentH = renderDetail(g, mx, my, y0);
        } else if (lib.tracks().isEmpty()) {
            contentH = renderEmpty(g, tr("empty_title"), tr("empty_hint"), tr("empty_hint2"), lib.dir().toString());
        } else {
            switch (view) {
                case ALBUMS -> contentH = shownAlbums.isEmpty() ? renderEmpty(g, tr("no_results"), "", "", "") : renderGrid(g, mx, my, y0);
                case ARTISTS -> contentH = shownArtists.isEmpty() ? renderEmpty(g, tr("no_results"), "", "", "") : renderArtists(g, mx, my, y0);
                default -> contentH = shownTracks.isEmpty() ? renderEmpty(g, tr("no_results"), "", "", "") : renderTracks(g, mx, my, y0 + 6, shownTracks) + 6;
            }
        }
        g.disableScissor();

        maxScroll = Math.max(0, contentH - (cy1 - cy0));
        scrollTarget = Mth.clamp(scrollTarget, 0, maxScroll);
        if (maxScroll > 0) {
            int track = cy1 - cy0 - 8;
            int thumb = Math.max(16, track * (cy1 - cy0) / Math.max(1, contentH));
            int ty = cy0 + 4 + (int) ((track - thumb) * (scrollShown / maxScroll));
            Ui.rounded(g, cx1 - 5, ty, cx1 - 2, ty + thumb, 1, Ui.alpha(0xFFFFFF, 0x30));
        }
    }

    private int renderEmpty(GuiGraphics g, String title, String hint1, String hint2, String path) {
        int cx = (cx0 + cx1) / 2, cy = (cy0 + cy1) / 2 - 24;
        Ui.scaledText(g, font, "♫", cx - 10, cy - 20, 3f, Ui.alpha(accent, 0xAA));
        g.drawString(font, Component.literal(title).withStyle(ChatFormatting.BOLD), cx - font.width(title) / 2, cy + 12, Ui.TEXT, false);
        if (!hint1.isEmpty()) g.drawString(font, hint1, cx - font.width(hint1) / 2, cy + 28, Ui.MUTED, false);
        if (!hint2.isEmpty()) g.drawString(font, hint2, cx - font.width(hint2) / 2, cy + 40, Ui.MUTED, false);
        if (!path.isEmpty()) {
            String p = Ui.clip(font, path, cx1 - cx0 - 30);
            g.drawString(font, p, cx - font.width(p) / 2, cy + 54, Ui.DIM, false);
        }
        return 0;
    }

    private void drawCover(GuiGraphics g, Album a, int x, int y, int s) {
        ResourceLocation tex = a != null ? a.texture() : null;
        if (tex != null) {
            g.blit(tex, x, y, s, s, 0f, 0f, Album.COVER, Album.COVER, Album.COVER, Album.COVER);
        } else {
            String n = a != null ? a.name : "";
            g.fillGradient(x, y, x + s, y + s, Ui.hueColor(n, 0.55f, 0.65f), Ui.hueColor(n + "~", 0.6f, 0.32f));
            float sc = Math.max(1f, s / 28f);
            Ui.scaledText(g, font, "♪", (int) (x + (s - font.width("♪") * sc) / 2f),
                    (int) (y + (s - 8 * sc) / 2f), sc, 0xCCFFFFFF);
        }
    }

    private int renderGrid(GuiGraphics g, int mx, int my, int y0) {
        int cardW = 82, gap = 8, pad = 10;
        int cols = Math.max(1, (cx1 - cx0 - 2 * pad + gap) / (cardW + gap));
        int cardH = cardW + 26;
        for (int i = 0; i < shownAlbums.size(); i++) {
            Album a = shownAlbums.get(i);
            int x = cx0 + pad + (i % cols) * (cardW + gap);
            int y = y0 + pad + (i / cols) * (cardH + gap);
            if (y + cardH < cy0 || y > cy1) continue;

            boolean hov = inContent(mx, my) && Ui.in(mx, my, x, y, x + cardW, y + cardH);
            Ui.rounded(g, x, y, x + cardW, y + cardH, 5, hov ? Ui.HOVER : Ui.CARD);
            int cs = cardW - 8;
            drawCover(g, a, x + 4, y + 4, cs);
            g.drawString(font, Ui.clip(font, a.name, cardW - 8), x + 4, y + cs + 8, Ui.TEXT, false);
            g.drawString(font, Ui.clip(font, a.artist, cardW - 8), x + 4, y + cs + 19, Ui.MUTED, false);
            hitC(x, y, x + cardW, y + cardH, () -> openAlbum(a));

            if (hov) {
                int px = x + 4 + cs - 22, py = y + 4 + cs - 22;
                boolean hp = Ui.in(mx, my, px, py, px + 18, py + 18);
                Ui.rounded(g, px, py, px + 18, py + 18, 9, hp ? Ui.mix(accent, 0xFFFFFFFF, 0.25f) : accent);
                Ui.play(g, px + 7, py + 4, 10, Ui.BG);
                hitC(px, py, px + 18, py + 18, () -> playAlbum(a, false));
            }
        }
        int rows = (shownAlbums.size() + cols - 1) / cols;
        return pad * 2 + rows * (cardH + gap);
    }

    private int renderArtists(GuiGraphics g, int mx, int my, int y0) {
        int x0 = cx0 + 8, x1 = cx1 - 10, rowH = 28;
        for (int i = 0; i < shownArtists.size(); i++) {
            Map.Entry<String, Integer> e = shownArtists.get(i);
            int y = y0 + 6 + i * rowH;
            if (y + rowH < cy0 || y > cy1) continue;
            boolean hov = inContent(mx, my) && Ui.in(mx, my, x0, y, x1, y + rowH - 2);
            if (hov) Ui.rounded(g, x0, y, x1, y + rowH - 2, 5, Ui.HOVER);
            int av = Ui.hueColor(e.getKey(), 0.5f, 0.6f);
            Ui.rounded(g, x0 + 6, y + 3, x0 + 28, y + 25, 11, av);
            String initial = e.getKey().isEmpty() ? "?" : e.getKey().substring(0, 1).toUpperCase(Locale.ROOT);
            g.drawString(font, initial, x0 + 17 - font.width(initial) / 2, y + 10, 0xFFFFFFFF, false);
            String count = tr("artist_meta", e.getValue());
            g.drawString(font, Ui.clip(font, e.getKey(), x1 - x0 - 60 - font.width(count)), x0 + 36, y + 10, Ui.TEXT, false);
            g.drawString(font, count, x1 - 8 - font.width(count), y + 10, Ui.MUTED, false);
            String name = e.getKey();
            hitC(x0, y, x1, y + rowH - 2, () -> {
                view = View.ALBUMS;
                artistFilter = name;
                scrollTarget = scrollShown = 0;
                dirty = true;
            });
        }
        return 12 + shownArtists.size() * rowH;
    }

    private int renderDetail(GuiGraphics g, int mx, int my, int y0) {
        Album a = openAlbum;
        if (a == null) return 0;
        int px = cx0 + 12, cs = 72;
        drawCover(g, a, px, y0 + 10, cs);
        int tx = px + cs + 12, tw = cx1 - tx - 14;
        Ui.scaledText(g, font, Ui.clip(font, a.name, (int) (tw / 1.5f)), tx, y0 + 12, 1.5f, Ui.TEXT);
        String meta = a.artist + (a.year > 0 ? "  ·  " + a.year : "");
        g.drawString(font, Ui.clip(font, meta, tw), tx, y0 + 30, Ui.MUTED, false);
        g.drawString(font, Ui.clip(font, tr("album_meta", a.tracks.size(), Ui.longTime(a.totalMs())), tw), tx, y0 + 42, Ui.DIM, false);

        int by = y0 + 58;
        String play = "▶  " + tr("play"), shuffle = tr("shuffle");
        int w1 = font.width(play) + 22, w2 = font.width(shuffle) + 22;
        button(g, mx, my, tx, by, tx + w1, by + 18, play, true, true, () -> playAlbum(a, false));
        button(g, mx, my, tx + w1 + 8, by, tx + w1 + 8 + w2, by + 18, shuffle, false, true, () -> playAlbum(a, true));

        return 96 + renderTracks(g, mx, my, y0 + 96, detailTracks);
    }

    private int renderTracks(GuiGraphics g, int mx, int my, int y0, List<Track> list) {
        int x0 = cx0 + 8, x1 = cx1 - 10, rowH = 22;
        int w = x1 - x0;
        boolean showAlbum = w > 380;
        int idxW = 24, durW = 34, heartW = 18;
        int textW = w - idxW - durW - heartW - 8;
        int titleW = showAlbum ? textW * 40 / 100 : textW * 60 / 100;
        int artistW = showAlbum ? textW * 28 / 100 : textW * 40 / 100 - 6;
        int albumW = showAlbum ? textW - titleW - artistW - 8 : 0;
        Track playing = engine.current();

        for (int i = 0; i < list.size(); i++) {
            Track t = list.get(i);
            int y = y0 + i * rowH;
            if (y + rowH < cy0 || y > cy1) continue;
            boolean cur = t == playing;
            boolean hov = inContent(mx, my) && Ui.in(mx, my, x0, y, x1, y + rowH - 2);
            if (cur) Ui.rounded(g, x0, y, x1, y + rowH - 2, 4, Ui.alpha(accent, 0x30));
            else if (hov) Ui.rounded(g, x0, y, x1, y + rowH - 2, 4, Ui.HOVER);

            int ty = y + 7;
            int idx = i;
            if (cur) {
                if (engine.isPlaying()) Ui.pause(g, x0 + 8, y + 6, 8, accent);
                else Ui.play(g, x0 + 8, y + 6, 8, accent);
            } else if (hov) {
                Ui.play(g, x0 + 8, y + 6, 8, Ui.TEXT);
            } else {
                String n = String.valueOf(i + 1);
                g.drawString(font, n, x0 + idxW / 2 + 2 - font.width(n) / 2, ty, Ui.DIM, false);
            }

            int cxp = x0 + idxW;
            g.drawString(font, Ui.clip(font, t.title, titleW), cxp, ty, cur ? accent : Ui.TEXT, false);
            cxp += titleW + 4;
            g.drawString(font, Ui.clip(font, t.artist, artistW), cxp, ty, Ui.MUTED, false);
            cxp += artistW + 4;
            if (showAlbum) g.drawString(font, Ui.clip(font, t.album, albumW), cxp, ty, Ui.MUTED, false);

            String dur = t.durationMs > 0 ? Ui.time(t.durationMs) : "--:--";
            g.drawString(font, dur, x1 - heartW - 4 - font.width(dur), ty, Ui.MUTED, false);
            boolean fav = lib.isFavorite(t);
            g.drawString(font, "♥", x1 - heartW + 3, ty, fav ? accent : Ui.DIM, false);

            hitC(x0, y, x1, y + rowH - 2, () -> engine.playQueue(list, idx));
            hitC(x1 - heartW, y, x1, y + rowH - 2, () -> { lib.toggleFavorite(t); if (view == View.FAVORITES) dirty = true; });
        }
        return list.size() * rowH + 8;
    }

    // ---- player bar ----

    private void renderBar(GuiGraphics g, int mx, int my) {
        int bx0 = wx0 + 6, bx1 = wx1 - 6, by0 = wy1 - BAR + 2, by1 = wy1 - 6;
        Ui.rounded(g, bx0, by0, bx1, by1, 6, Ui.PANEL);

        Track t = engine.current();
        long dur = t == null ? 0 : t.durationMs;

        // left: cover + titles
        int cs = 36;
        drawCover(g, t != null ? t.albumRef : null, bx0 + 8, by0 + 6, cs);
        int leftEnd = bx0 + 8 + Math.min(180, (bx1 - bx0) * 28 / 100);
        int textX = bx0 + 8 + cs + 8;
        if (t != null) {
            g.drawString(font, Ui.clip(font, t.title, leftEnd - textX), textX, by0 + 12, Ui.TEXT, false);
            String sub = engine.error() != null ? "⚠ " + engine.error() : t.artist;
            g.drawString(font, Ui.clip(font, sub, leftEnd - textX), textX, by0 + 25, engine.error() != null ? 0xFFFF6B6B : Ui.MUTED, false);
        } else {
            g.drawString(font, Ui.clip(font, tr("nothing_playing"), leftEnd - textX), textX, by0 + 19, Ui.DIM, false);
        }

        // right: visualizer + volume
        int rightStart = bx1 - 8 - 104;
        engine.copyLevels(levels);
        boolean playing = engine.isPlaying();
        for (int i = 0; i < levels.length; i++) {
            int h = 1 + (int) ((playing ? levels[i] : levels[i] * 0.4f) * 17);
            int x = rightStart + i * 4;
            g.fill(x, by0 + 26 - h, x + 3, by0 + 26, Ui.alpha(accent, 0x40 + (int) (levels[i] * 0xB0)));
        }
        volX0 = rightStart + 26;
        volX1 = rightStart + 104;
        volY0 = by0 + 34;
        g.drawString(font, tr("volume"), rightStart, by0 + 32, Ui.MUTED, false);
        Ui.rounded(g, volX0, volY0, volX1, volY0 + 4, 2, Ui.HOVER);
        int vw = (int) ((volX1 - volX0) * engine.volume());
        if (vw > 0) Ui.rounded(g, volX0, volY0, volX0 + vw, volY0 + 4, 2, accent);
        if (dragVolume || Ui.in(mx, my, volX0 - 3, volY0 - 4, volX1 + 3, volY0 + 10)) {
            Ui.rounded(g, volX0 + vw - 3, volY0 - 2, volX0 + vw + 3, volY0 + 6, 3, 0xFFFFFFFF);
        }

        // center: transport
        int cL = leftEnd + 10, cR = rightStart - 10, cM = (cL + cR) / 2;
        int cy = by0 + 5;
        boolean hp = Ui.in(mx, my, cM - 11, cy, cM + 11, cy + 22);
        Ui.rounded(g, cM - 11, cy, cM + 11, cy + 22, 11, hp ? 0xFFFFFFFF : Ui.TEXT);
        if (playing) Ui.pause(g, cM - 4, cy + 6, 10, Ui.BG);
        else Ui.play(g, cM - 3, cy + 6, 10, Ui.BG);
        hit(cM - 11, cy, cM + 11, cy + 22, engine::togglePause);

        int iy = cy + 6;
        boolean hv = Ui.in(mx, my, cM - 40, cy, cM - 18, cy + 22);
        Ui.prev(g, cM - 34, iy, 10, hv ? Ui.TEXT : Ui.MUTED);
        hit(cM - 40, cy, cM - 18, cy + 22, engine::previous);
        boolean hn = Ui.in(mx, my, cM + 18, cy, cM + 40, cy + 22);
        Ui.next(g, cM + 22, iy, 10, hn ? Ui.TEXT : Ui.MUTED);
        hit(cM + 18, cy, cM + 40, cy + 22, engine::next);

        String sh = tr("shuffle");
        int shW = font.width(sh) + 12;
        int sx1 = cM - 50;
        boolean son = engine.shuffle();
        Ui.rounded(g, sx1 - shW, cy + 4, sx1, cy + 18, 7, son ? Ui.alpha(accent, 0x44) : Ui.CARD);
        g.drawString(font, sh, sx1 - shW + 6, cy + 7, son ? accent : Ui.MUTED, false);
        hit(sx1 - shW, cy + 4, sx1, cy + 18, engine::toggleShuffle);

        AudioEngine.Repeat rep = engine.repeat();
        String rl = tr(rep == AudioEngine.Repeat.OFF ? "repeat" : rep == AudioEngine.Repeat.ALL ? "repeat_all" : "repeat_one");
        int rw = font.width(tr("repeat_all")) + 12;
        int rx0 = cM + 50;
        boolean ron = rep != AudioEngine.Repeat.OFF;
        Ui.rounded(g, rx0, cy + 4, rx0 + rw, cy + 18, 7, ron ? Ui.alpha(accent, 0x44) : Ui.CARD);
        g.drawString(font, rl, rx0 + (rw - font.width(rl)) / 2, cy + 7, ron ? accent : Ui.MUTED, false);
        hit(rx0, cy + 4, rx0 + rw, cy + 18, engine::cycleRepeat);

        // center: progress
        progX0 = cL + 32;
        progX1 = cR - 32;
        progY0 = by0 + 34;
        long pos = dragProgress ? (long) (seekFrac * dur) : engine.positionMs();
        float frac = dur > 0 ? Mth.clamp(pos / (float) dur, 0f, 1f) : 0f;
        g.drawString(font, Ui.time(pos), cL, by0 + 32, Ui.MUTED, false);
        String end = dur > 0 ? Ui.time(dur) : "--:--";
        g.drawString(font, end, cR - font.width(end), by0 + 32, Ui.MUTED, false);
        Ui.rounded(g, progX0, progY0, progX1, progY0 + 4, 2, Ui.HOVER);
        int fw = (int) ((progX1 - progX0) * frac);
        if (fw > 0) Ui.rounded(g, progX0, progY0, progX0 + fw, progY0 + 4, 2, accent);
        if (dur > 0 && (dragProgress || Ui.in(mx, my, progX0 - 3, progY0 - 4, progX1 + 3, progY0 + 10))) {
            Ui.rounded(g, progX0 + fw - 3, progY0 - 2, progX0 + fw + 3, progY0 + 6, 3, 0xFFFFFFFF);
        }
    }

    // ------------------------------------------------------------------ input

    private static float frac(double mx, int x0, int x1) {
        return Mth.clamp((float) ((mx - x0) / Math.max(1, x1 - x0)), 0f, 1f);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            if (currentDuration() > 0 && Ui.in(mx, my, progX0 - 3, progY0 - 4, progX1 + 3, progY0 + 10)) {
                dragProgress = true;
                seekFrac = frac(mx, progX0, progX1);
                return true;
            }
            if (Ui.in(mx, my, volX0 - 3, volY0 - 4, volX1 + 3, volY0 + 10)) {
                dragVolume = true;
                engine.setVolume(frac(mx, volX0, volX1));
                return true;
            }
        }
        if (super.mouseClicked(mx, my, button)) return true;
        if (button == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (Ui.in(mx, my, h.x0(), h.y0(), h.x1(), h.y1())) {
                    h.action().run();
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragProgress) {
            seekFrac = frac(mx, progX0, progX1);
            return true;
        }
        if (dragVolume) {
            engine.setVolume(frac(mx, volX0, volX1));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragProgress) {
            dragProgress = false;
            long d = currentDuration();
            if (d > 0) engine.seek((long) (seekFrac * d));
            return true;
        }
        if (dragVolume) {
            dragVolume = false;
            saveVolume();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        if (inContent(mx, my)) {
            scrollTarget = Mth.clamp(scrollTarget - (float) scrollY * 28f, 0, maxScroll);
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (super.keyPressed(key, scan, mods)) return true;
        boolean typing = getFocused() instanceof EditBox eb && eb.isFocused();
        if (!typing) {
            if (key == GLFW.GLFW_KEY_SPACE) {
                engine.togglePause();
                return true;
            }
            if (VinylDeckClient.OPEN.matches(key, scan)) {
                onClose();
                return true;
            }
        }
        return false;
    }

    /** Drag & drop MP3/OGG/WAV files (or folders) onto the window to add them to the library. */
    @Override
    public void onFilesDrop(List<Path> paths) {
        lib.importFiles(paths, n -> {
            statusMsg = tr("added", n);
            statusUntil = System.currentTimeMillis() + 4000;
        });
    }
}
