package dev.vinyldeck.client.audio;

import java.io.RandomAccessFile;
import java.nio.file.Path;

/** Computes the duration of an Ogg Vorbis file from the last page's granule position. */
final class OggInfo {
    private OggInfo() {}

    static long durationMs(Path p) {
        try (RandomAccessFile f = new RandomAccessFile(p.toFile(), "r")) {
            long len = f.length();
            byte[] head = new byte[(int) Math.min(4096, len)];
            f.readFully(head);
            int i = indexOfVorbisHeader(head);
            if (i < 0 || i + 16 > head.length) return 0;
            int rate = le32(head, i + 12);   // 7 magic + 4 version + 1 channels
            int tailLen = (int) Math.min(len, 65536);
            byte[] tail = new byte[tailLen];
            f.seek(len - tailLen);
            f.readFully(tail);
            long granule = -1;
            for (int j = tailLen - 14; j >= 0; j--) {
                if (tail[j] == 'O' && tail[j + 1] == 'g' && tail[j + 2] == 'g' && tail[j + 3] == 'S') {
                    granule = le64(tail, j + 6);
                    break;
                }
            }
            if (granule <= 0 || rate <= 0) return 0;
            return granule * 1000L / rate;
        } catch (Exception e) {
            return 0;
        }
    }

    private static int indexOfVorbisHeader(byte[] b) {
        byte[] magic = {1, 'v', 'o', 'r', 'b', 'i', 's'};
        outer:
        for (int i = 0; i + magic.length <= b.length; i++) {
            for (int k = 0; k < magic.length; k++) if (b[i + k] != magic[k]) continue outer;
            return i;
        }
        return -1;
    }

    private static int le32(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24);
    }

    private static long le64(byte[] b, int o) {
        long v = 0;
        for (int i = 7; i >= 0; i--) v = (v << 8) | (b[o + i] & 0xFF);
        return v;
    }
}
