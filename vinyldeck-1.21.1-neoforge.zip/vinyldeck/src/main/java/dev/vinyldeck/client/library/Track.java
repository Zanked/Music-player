package dev.vinyldeck.client.library;

import java.nio.file.Path;

public final class Track {
    public final Path path;
    public final String id;
    public final String title;
    public final String artist;
    public final String album;
    public final int year;
    public final int trackNo;
    public final long durationMs;
    public final long addedAt;
    /** Set by the library after scanning. */
    public Album albumRef;

    public Track(Path path, String id, String title, String artist, String album,
                 int year, int trackNo, long durationMs, long addedAt) {
        this.path = path;
        this.id = id;
        this.title = title;
        this.artist = artist;
        this.album = album;
        this.year = year;
        this.trackNo = trackNo;
        this.durationMs = durationMs;
        this.addedAt = addedAt;
    }
}
