package dev.vinyldeck.client.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** Small drawing toolkit: palette, rounded rectangles, vector-ish icons, text helpers. */
public final class Ui {
    public static final int BG = 0xFF0E1014;
    public static final int PANEL = 0xFF161920;
    public static final int CARD = 0xFF1C2028;
    public static final int HOVER = 0xFF272C38;
    public static final int TEXT = 0xFFF2F4F8;
    public static final int MUTED = 0xFF8B93A3;
    public static final int DIM = 0xFF4A5060;
    public static final int DEFAULT_ACCENT = 0xFF7C5CFF;

    private Ui() {}

    public static int alpha(int rgb, int a) { return (a << 24) | (rgb & 0xFFFFFF); }

    public static int mix(int a, int b, float t) {
        int r = (int) Mth.lerp(t, (a >> 16) & 255, (b >> 16) & 255);
        int g = (int) Mth.lerp(t, (a >> 8) & 255, (b >> 8) & 255);
        int bl = (int) Mth.lerp(t, a & 255, b & 255);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    public static int hueColor(String s, float sat, float val) {
        float h = ((s.hashCode() & 0x7FFFFFFF) % 360) / 360f;
        return 0xFF000000 | Mth.hsvToRgb(h, sat, val);
    }

    public static boolean in(double mx, double my, int x0, int y0, int x1, int y1) {
        return mx >= x0 && mx < x1 && my >= y0 && my < y1;
    }

    public static void rounded(GuiGraphics g, int x1, int y1, int x2, int y2, int r, int color) {
        r = Math.min(r, Math.min((x2 - x1) / 2, (y2 - y1) / 2));
        if (r <= 0) {
            g.fill(x1, y1, x2, y2, color);
            return;
        }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            g.fill(x1 + inset, y1 + i, x2 - inset, y1 + i + 1, color);
            g.fill(x1 + inset, y2 - i - 1, x2 - inset, y2 - i, color);
        }
        g.fill(x1, y1 + r, x2, y2 - r, color);
    }

    public static String clip(Font font, String s, int maxWidth) {
        if (maxWidth <= 0) return "";
        if (font.width(s) <= maxWidth) return s;
        int ell = font.width("…");
        return font.plainSubstrByWidth(s, Math.max(0, maxWidth - ell)) + "…";
    }

    public static void scaledText(GuiGraphics g, Font font, String s, int x, int y, float scale, int color) {
        g.pose().pushPose();
        g.pose().translate((float) x, (float) y, 0f);
        g.pose().scale(scale, scale, 1f);
        g.drawString(font, s, 0, 0, color, false);
        g.pose().popPose();
    }

    // ---- icons (drawn with fills so they never depend on font glyphs) ----

    public static int triWidth(int h) { return (int) Math.round(h * 0.85); }

    public static void play(GuiGraphics g, int x, int y, int h, int c) {
        for (int i = 0; i < h; i++) {
            double t = 1 - Math.abs((i + 0.5) / (h / 2.0) - 1);
            int w = (int) Math.round(t * h * 0.85);
            if (w > 0) g.fill(x, y + i, x + w, y + i + 1, c);
        }
    }

    public static void pause(GuiGraphics g, int x, int y, int h, int c) {
        int bw = Math.max(2, h / 3);
        int gap = Math.max(2, h / 4);
        g.fill(x, y, x + bw, y + h, c);
        g.fill(x + bw + gap, y, x + 2 * bw + gap, y + h, c);
    }

    public static void next(GuiGraphics g, int x, int y, int h, int c) {
        play(g, x, y, h, c);
        g.fill(x + triWidth(h) + 1, y, x + triWidth(h) + 3, y + h, c);
    }

    public static void prev(GuiGraphics g, int x, int y, int h, int c) {
        int w = triWidth(h);
        g.fill(x, y, x + 2, y + h, c);
        for (int i = 0; i < h; i++) {
            double t = 1 - Math.abs((i + 0.5) / (h / 2.0) - 1);
            int rw = (int) Math.round(t * h * 0.85);
            if (rw > 0) g.fill(x + 3 + (w - rw), y + i, x + 3 + w, y + i + 1, c);
        }
    }

    // ---- time ----

    public static String time(long ms) {
        long s = Math.max(0, ms / 1000);
        return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
    }

    public static String longTime(long ms) {
        long m = ms / 60000;
        return m >= 60 ? (m / 60) + " h " + (m % 60) + " min" : m + " min";
    }
}
