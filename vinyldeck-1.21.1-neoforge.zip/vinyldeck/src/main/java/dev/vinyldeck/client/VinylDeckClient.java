package dev.vinyldeck.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.vinyldeck.VinylDeck;
import dev.vinyldeck.client.audio.AudioEngine;
import dev.vinyldeck.client.library.Library;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.lwjgl.glfw.GLFW;

@Mod(value = VinylDeck.MODID, dist = Dist.CLIENT)
public class VinylDeckClient {
    private static final String CATEGORY = "key.categories.vinyldeck";

    public static final KeyMapping OPEN = new KeyMapping("key.vinyldeck.open",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_M, CATEGORY);
    public static final KeyMapping PLAY_PAUSE = new KeyMapping("key.vinyldeck.play_pause",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, CATEGORY);
    public static final KeyMapping NEXT = new KeyMapping("key.vinyldeck.next",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, CATEGORY);
    public static final KeyMapping PREVIOUS = new KeyMapping("key.vinyldeck.previous",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, CATEGORY);

    public VinylDeckClient(IEventBus modBus, ModContainer container) {
        container.registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);
        modBus.addListener(VinylDeckClient::registerKeys);
        modBus.addListener(VinylDeckClient::clientSetup);
        NeoForge.EVENT_BUS.addListener(ClientEvents::onTick);
        NeoForge.EVENT_BUS.addListener(ClientEvents::onLogout);
    }

    private static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(OPEN);
        event.register(PLAY_PAUSE);
        event.register(NEXT);
        event.register(PREVIOUS);
    }

    private static void clientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            AudioEngine.INSTANCE.setVolume(ClientConfig.VOLUME.get().floatValue());
            Library.INSTANCE.loadFavorites();
            if (ClientConfig.SCAN_ON_STARTUP.get()) {
                Library.INSTANCE.rescan();
            }
        });
    }
}
