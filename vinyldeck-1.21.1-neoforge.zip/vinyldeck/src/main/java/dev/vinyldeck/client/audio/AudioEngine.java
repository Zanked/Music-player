package dev.vinyldeck.client.audio;

import com.mojang.logging.LogUtils;
import dev.vinyldeck.client.library.Track;
import net.minecraft.client.Minecraft;
import org.slf4j.Logger;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Random;

/**
 * Plays the queue through Java Sound on a background thread.
 * Control methods are meant to be called from the client thread.
 */
public final class AudioEngine {
    public static final AudioEngine INSTANCE = new AudioEngine();
    public static final int LEVELS = 26;

    public enum Repeat { OFF, ALL, ONE }

    private static final Logger LOG = LogUtils.getLogger();

    private volatile int generation;
    private volatile boolean paused;
    private volatile boolean ended;
    private volatile Track current;
    private volatile SourceDataLine activeLine;
    private volatile long runStartMs;
    private volatile float volume = 0.7f;
    private volatile float external = 1f;
    private volatile String error;

    private final float[] levels = new float[LEVELS];
    private int levelTick;
    private float levelAcc;

    private List<Track> queue = new ArrayList<>();
    private int index = -1;
    private final Deque<Integer> history = new ArrayDeque<>();
    private final Random rng = new Random();
    private boolean shuffle;
    private Repeat repeat = Repeat.OFF;

    private AudioEngine() {}

    // ------------------------------------------------------------ state

    public Track current() { return current; }
    public boolean isPlaying() { return current != null && !paused && !ended; }
    public String error() { return error; }
    public float volume() { return volume; }
    public boolean shuffle() { return shuffle; }
    public Repeat repeat() { return repeat; }

    public void setVolume(float v) { volume = Math.max(0f, Math.min(1f, v)); }
    public void setExternalVolume(float v) { external = v; }

    public void toggleShuffle() { shuffle = !shuffle; }

    public void cycleRepeat() {
        repeat = Repeat.values()[(repeat.ordinal() + 1) % Repeat.values().length];
    }

    public long positionMs() {
        Track t = current;
        if (t == null || ended) return 0;
        SourceDataLine l = activeLine;
        long p = l == null ? runStartMs : runStartMs + l.getMicrosecondPosition() / 1000;
        if (t.durationMs > 0) p = Math.min(p, t.durationMs);
        return p;
    }

    public void copyLevels(float[] out) {
        synchronized (levels) {
            System.arraycopy(levels, 0, out, 0, Math.min(out.length, levels.length));
        }
    }

    // ------------------------------------------------------------ controls

    public void playQueue(List<Track> tracks, int startIndex) {
        if (tracks.isEmpty()) return;
        queue = new ArrayList<>(tracks);
        index = Math.max(0, Math.min(startIndex, queue.size() - 1));
        history.clear();
        current = queue.get(index);
        start(0, false);
    }

    public void togglePause() {
        if (current == null) return;
        if (ended) {
            start(0, false);
            return;
        }
        paused = !paused;
    }

    public void next() { advance(true); }

    public void previous() {
        if (queue.isEmpty() || current == null) return;
        if (positionMs() > 3000) {
            start(0, true);
            return;
        }
        if (shuffle && !history.isEmpty()) {
            index = history.pop();
        } else {
            index = index - 1 < 0 ? (repeat == Repeat.ALL ? queue.size() - 1 : 0) : index - 1;
        }
        current = queue.get(index);
        start(0, false);
    }

    public void seek(long ms) {
        if (current == null) return;
        start(Math.max(0, ms), paused && !ended);
    }

    public void stop() {
        generation++;
        current = null;
        activeLine = null;
        paused = false;
        ended = false;
        error = null;
        synchronized (levels) { java.util.Arrays.fill(levels, 0f); }
    }

    // ------------------------------------------------------------ queue logic

    private void advance(boolean manual) {
        if (queue.isEmpty()) return;
        if (shuffle && queue.size() > 1) {
            history.push(index);
            int n;
            do { n = rng.nextInt(queue.size()); } while (n == index);
            index = n;
        } else {
            int n = index + 1;
            if (n >= queue.size()) {
                if (repeat == Repeat.ALL || manual) {
                    n = 0;
                } else {
                    generation++;
                    activeLine = null;
                    ended = true;
                    return;
                }
            }
            index = n;
        }
        current = queue.get(index);
        start(0, false);
    }

    private void onTrackEnded() {
        if (repeat == Repeat.ONE) start(0, false);
        else advance(false);
    }

    private void start(long startMs, boolean keepPaused) {
        Track t = current;
        if (t == null) return;
        int gen = ++generation;
        activeLine = null;
        runStartMs = startMs;
        error = null;
        ended = false;
        if (!keepPaused) paused = false;
        Thread th = new Thread(() -> run(t, startMs, gen), "VinylDeck-Audio");
        th.setDaemon(true);
        th.start();
    }

    // ------------------------------------------------------------ playback thread

    private void run(Track track, long startMs, int gen) {
        SourceDataLine line = null;
        PcmSource src = null;
        try {
            src = Decoders.open(track.path, startMs);
            AudioFormat fmt = src.format();
            int fs = fmt.getFrameSize();
            line = (SourceDataLine) AudioSystem.getLine(new DataLine.Info(SourceDataLine.class, fmt));
            int buffer = Math.max(fs * 4096, (int) (fmt.getFrameRate() * 0.2f) * fs);
            line.open(fmt, buffer);
            line.start();
            if (gen != generation) return;
            activeLine = line;

            byte[] buf = new byte[fs * 1024];
            boolean stopped = false;
            while (gen == generation) {
                if (paused) {
                    if (!stopped) { line.stop(); stopped = true; }
                    sleep(25);
                    continue;
                }
                if (stopped) { line.start(); stopped = false; }
                int n = src.read(buf, 0, buf.length);
                if (n < 0) break;
                n -= n % fs;
                if (n <= 0) continue;
                feedLevels(buf, n);
                applyVolume(buf, n);
                int off = 0;
                while (off < n && gen == generation) off += line.write(buf, off, n - off);
            }
            if (gen == generation) {
                line.drain();
                if (gen == generation) {
                    Minecraft.getInstance().execute(() -> { if (gen == generation) onTrackEnded(); });
                }
            }
        } catch (Exception e) {
            LOG.warn("Playback failed for {}", track.path, e);
            if (gen == generation) {
                error = String.valueOf(e.getMessage());
                ended = true;
            }
        } finally {
            if (line != null) {
                try { line.stop(); line.close(); } catch (Exception ignored) { }
                if (activeLine == line) activeLine = null;
            }
            if (src != null) {
                try { src.close(); } catch (IOException ignored) { }
            }
        }
    }

    private void applyVolume(byte[] b, int n) {
        float v = volume * external;
        v = v * v; // perceptual curve
        if (v >= 0.999f) return;
        for (int i = 0; i + 1 < n; i += 2) {
            int s = (short) ((b[i] & 0xFF) | (b[i + 1] << 8));
            s = (int) (s * v);
            b[i] = (byte) s;
            b[i + 1] = (byte) (s >> 8);
        }
    }

    /** Scrolling loudness history used by the mini visualizer. */
    private void feedLevels(byte[] b, int n) {
        long sum = 0;
        int cnt = 0;
        for (int i = 0; i + 1 < n; i += 2) {
            short s = (short) ((b[i] & 0xFF) | (b[i + 1] << 8));
            sum += (long) s * s;
            cnt++;
        }
        float rms = cnt == 0 ? 0f : (float) (Math.sqrt(sum / (double) cnt) / 32768.0);
        levelAcc = Math.max(levelAcc, rms);
        if (++levelTick >= 3) {
            levelTick = 0;
            synchronized (levels) {
                System.arraycopy(levels, 1, levels, 0, levels.length - 1);
                levels[levels.length - 1] = Math.min(1f, levelAcc * 2.8f);
            }
            levelAcc = 0f;
        }
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
    }
}
