package dev.vinyldeck.client.library;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mojang.logging.LogUtils;
import dev.vinyldeck.client.audio.Decoders;
import net.minecraft.client.Minecraft;
import net.neoforged.fml.loading.FMLPaths;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.IntConsumer;
import java.util.stream.Stream;

/** The user's music collection: scanning, albums, favorites. Safe to read from any thread. */
public final class Library {
    public static final Library INSTANCE = new Library();
    public static final String UNKNOWN_ARTIST = "Unknown artist";
    public static final String UNKNOWN_ALBUM = "Unknown album";

    private static final Logger LOG = LogUtils.getLogger();
    private static final Set<String> EXT = Set.of("mp3", "ogg", "wav");
    private static final String[] COVER_NAMES = {"cover", "folder", "front", "album", "artwork"};
    private static final String[] COVER_EXT = {"jpg", "jpeg", "png"};

    private volatile List<Track> tracks = List.of();
    private volatile List<Album> albums = List.of();
    private volatile int revision;
    private boolean scanning;
    private boolean rescanQueued;
    private final Set<String> favorites = ConcurrentHashMap.newKeySet();

    private Library() {}

    // ---------- paths ----------

    public Path dir() {
        return FMLPaths.GAMEDIR.get().resolve("musicplayer").resolve("library");
    }

    private Path favoritesFile() {
        return FMLPaths.GAMEDIR.get().resolve("musicplayer").resolve("favorites.json");
    }

    // ---------- accessors ----------

    public List<Track> tracks() { return tracks; }
    public List<Album> albums() { return albums; }
    public int revision() { return revision; }
    public synchronized boolean scanning() { return scanning; }

    public Album findAlbum(String name) {
        for (Album a : albums) if (a.name.equalsIgnoreCase(name)) return a;
        return null;
    }

    // ---------- favorites ----------

    public boolean isFavorite(Track t) { return favorites.contains(t.id); }

    public void toggleFavorite(Track t) {
        if (!favorites.remove(t.id)) favorites.add(t.id);
        saveFavorites();
    }

    public void loadFavorites() {
        Path f = favoritesFile();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            List<String> list = new Gson().fromJson(r, new TypeToken<List<String>>() {}.getType());
            if (list != null) favorites.addAll(list);
        } catch (Exception e) {
            LOG.warn("Could not read favorites", e);
        }
    }

    private void saveFavorites() {
        Path f = favoritesFile();
        try {
            Files.createDirectories(f.getParent());
            try (Writer w = Files.newBufferedWriter(f)) {
                new Gson().toJson(new ArrayList<>(favorites), w);
            }
        } catch (IOException e) {
            LOG.warn("Could not save favorites", e);
        }
    }

    // ---------- import (drag & drop) ----------

    /** Copies dropped files/folders into the library folder, then rescans. Callback runs on the client thread. */
    public void importFiles(List<Path> paths, IntConsumer onDone) {
        List<Path> copy = List.copyOf(paths);
        Thread t = new Thread(() -> {
            int n = 0;
            Path root = dir();
            try {
                Files.createDirectories(root);
                for (Path p : copy) {
                    if (Files.isDirectory(p)) {
                        Path target = root.resolve(p.getFileName().toString());
                        List<Path> files;
                        try (Stream<Path> s = Files.walk(p)) {
                            files = s.filter(Files::isRegularFile).filter(Library::supported).toList();
                        }
                        for (Path f : files) {
                            Path dst = target.resolve(p.relativize(f).toString());
                            Files.createDirectories(dst.getParent());
                            Files.copy(f, dst, StandardCopyOption.REPLACE_EXISTING);
                            n++;
                        }
                    } else if (supported(p)) {
                        Files.copy(p, root.resolve(p.getFileName().toString()), StandardCopyOption.REPLACE_EXISTING);
                        n++;
                    }
                }
            } catch (IOException e) {
                LOG.warn("Import failed", e);
            }
            if (n > 0) rescan();
            int total = n;
            Minecraft.getInstance().execute(() -> onDone.accept(total));
        }, "VinylDeck-Import");
        t.setDaemon(true);
        t.start();
    }

    // ---------- scanning ----------

    public synchronized void rescan() {
        if (scanning) {
            rescanQueued = true;
            return;
        }
        scanning = true;
        Thread t = new Thread(this::scan, "VinylDeck-Scan");
        t.setDaemon(true);
        t.start();
    }

    private void scan() {
        try {
            Path root = dir();
            Files.createDirectories(root);
            List<Path> files;
            try (Stream<Path> s = Files.walk(root)) {
                files = s.filter(Files::isRegularFile).filter(Library::supported).sorted().toList();
            }

            List<Track> all = new ArrayList<>();
            Map<String, byte[]> covers = new HashMap<>();
            for (Path f : files) {
                try {
                    String ext = ext(f);
                    TagReader.Meta m = ext.equals("mp3") ? TagReader.readId3(f) : TagReader.EMPTY;
                    Track t = buildTrack(root, f, m);
                    all.add(t);
                    if (m.cover() != null) covers.putIfAbsent(t.album.toLowerCase(Locale.ROOT), m.cover());
                } catch (Exception e) {
                    LOG.warn("Skipping {}", f, e);
                }
            }

            Map<String, Album> byName = new LinkedHashMap<>();
            for (Track t : all) {
                Album a = byName.computeIfAbsent(t.album.toLowerCase(Locale.ROOT), k -> new Album(t.album));
                a.tracks.add(t);
                t.albumRef = a;
            }
            for (Map.Entry<String, Album> e : byName.entrySet()) {
                finishAlbum(e.getValue(), covers.get(e.getKey()));
            }

            List<Album> oldAlbums = albums;
            this.tracks = List.copyOf(all);
            this.albums = List.copyOf(byName.values());
            this.revision++;
            Minecraft.getInstance().execute(() -> oldAlbums.forEach(Album::releaseTexture));
        } catch (Exception e) {
            LOG.error("Library scan failed", e);
        } finally {
            boolean again;
            synchronized (this) {
                scanning = false;
                again = rescanQueued;
                rescanQueued = false;
            }
            if (again) rescan();
        }
    }

    private Track buildTrack(Path root, Path f, TagReader.Meta m) throws IOException {
        String base = stripExt(f.getFileName().toString());
        String title = m.title();
        String artist = m.artist();
        if (blank(title)) {
            int i = base.indexOf(" - ");
            if (i > 0 && blank(artist)) {
                artist = base.substring(0, i).trim();
                title = base.substring(i + 3).trim();
            } else {
                title = base;
            }
        }
        if (blank(artist)) artist = UNKNOWN_ARTIST;

        String album = m.album();
        Path rel = root.relativize(f);
        if (blank(album)) {
            album = rel.getNameCount() > 1 ? rel.getName(rel.getNameCount() - 2).toString() : UNKNOWN_ALBUM;
        }
        String id = rel.toString().replace('\\', '/');
        return new Track(f, id, title, artist, album, m.year(), m.trackNo(),
                Decoders.durationMs(f), Files.getLastModifiedTime(f).toMillis());
    }

    private void finishAlbum(Album a, byte[] embeddedCover) {
        Map<String, Integer> artistCount = new HashMap<>();
        for (Track t : a.tracks) {
            artistCount.merge(t.artist, 1, Integer::sum);
            if (t.year > 0 && (a.year == 0 || t.year < a.year)) a.year = t.year;
            a.addedAt = Math.max(a.addedAt, t.addedAt);
        }
        a.artist = artistCount.size() == 1 ? artistCount.keySet().iterator().next() : "Various artists";
        a.tracks.sort(Comparator.comparingInt((Track t) -> t.trackNo == 0 ? Integer.MAX_VALUE : t.trackNo)
                .thenComparing(t -> t.title, String.CASE_INSENSITIVE_ORDER));

        byte[] cover = embeddedCover;
        if (cover == null) cover = folderCover(a.tracks.get(0).path.getParent());
        if (cover != null) Covers.apply(a, cover);
    }

    private static byte[] folderCover(Path dir) {
        if (dir == null) return null;
        for (String n : COVER_NAMES) {
            for (String e : COVER_EXT) {
                Path p = dir.resolve(n + "." + e);
                if (Files.isRegularFile(p)) {
                    try {
                        return Files.readAllBytes(p);
                    } catch (IOException ignored) {
                        // try the next candidate
                    }
                }
            }
        }
        return null;
    }

    // ---------- helpers ----------

    public static boolean supported(Path p) { return EXT.contains(ext(p)); }

    public static String ext(Path p) {
        String n = p.getFileName().toString();
        int i = n.lastIndexOf('.');
        return i < 0 ? "" : n.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    private static String stripExt(String n) {
        int i = n.lastIndexOf('.');
        return i < 0 ? n : n.substring(0, i);
    }

    private static boolean blank(String s) { return s == null || s.isBlank(); }
}
