package dev.vinyldeck.client.library;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;

/** Decodes embedded/folder artwork into a small square ARGB bitmap and picks an accent color. */
final class Covers {
    private Covers() {}

    static void apply(Album album, byte[] bytes) {
        try {
            BufferedImage src = ImageIO.read(new ByteArrayInputStream(bytes));
            if (src == null) return;
            int size = Math.min(src.getWidth(), src.getHeight());
            BufferedImage cur = src.getSubimage((src.getWidth() - size) / 2, (src.getHeight() - size) / 2, size, size);
            int w = size;
            while (w / 2 >= Album.COVER) {
                w /= 2;
                cur = scale(cur, w);
            }
            cur = scale(cur, Album.COVER);
            int[] px = cur.getRGB(0, 0, Album.COVER, Album.COVER, null, 0, Album.COVER);
            album.coverPixels = px;
            album.accent = accent(px);
        } catch (Exception ignored) {
            // unsupported image: the UI falls back to a generated placeholder
        }
    }

    private static BufferedImage scale(BufferedImage in, int size) {
        BufferedImage out = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(in, 0, 0, size, size, null);
        g.dispose();
        return out;
    }

    /** Saturation-weighted average color, lightened so it stays readable on a dark UI. */
    private static int accent(int[] px) {
        double r = 0, g = 0, b = 0, wsum = 0;
        for (int p : px) {
            int pr = (p >> 16) & 255, pg = (p >> 8) & 255, pb = p & 255;
            double wgt = (Math.max(pr, Math.max(pg, pb)) - Math.min(pr, Math.min(pg, pb))) + 12;
            r += pr * wgt; g += pg * wgt; b += pb * wgt; wsum += wgt;
        }
        int ar = (int) (r / wsum), ag = (int) (g / wsum), ab = (int) (b / wsum);
        double lum = 0.299 * ar + 0.587 * ag + 0.114 * ab;
        if (lum < 120) {
            double t = (120 - lum) / 120.0 * 0.6;
            ar += (int) ((255 - ar) * t); ag += (int) ((255 - ag) * t); ab += (int) ((255 - ab) * t);
        }
        return 0xFF000000 | (Math.min(255, ar) << 16) | (Math.min(255, ag) << 8) | Math.min(255, ab);
    }
}
