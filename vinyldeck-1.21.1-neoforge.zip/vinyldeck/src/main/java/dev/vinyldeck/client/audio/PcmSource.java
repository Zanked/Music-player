package dev.vinyldeck.client.audio;

import javax.sound.sampled.AudioFormat;
import java.io.Closeable;
import java.io.IOException;

/** A stream of 16-bit signed little-endian PCM. */
public interface PcmSource extends Closeable {
    AudioFormat format();

    /** Reads up to len bytes, returns -1 at end of stream. */
    int read(byte[] buf, int off, int len) throws IOException;
}
