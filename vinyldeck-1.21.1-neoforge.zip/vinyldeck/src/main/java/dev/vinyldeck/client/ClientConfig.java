package dev.vinyldeck.client;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class ClientConfig {
    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    public static final ModConfigSpec.DoubleValue VOLUME = B
            .comment("Player volume (0.0 - 1.0). Multiplied by the game's master volume.")
            .defineInRange("volume", 0.7, 0.0, 1.0);

    public static final ModConfigSpec.BooleanValue SCAN_ON_STARTUP = B
            .comment("Scan the music library in the background when the game starts.")
            .define("scanOnStartup", true);

    public static final ModConfigSpec SPEC = B.build();

    private ClientConfig() {}
}
