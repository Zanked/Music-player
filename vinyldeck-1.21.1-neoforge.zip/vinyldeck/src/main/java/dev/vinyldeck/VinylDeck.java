package dev.vinyldeck;

import net.minecraft.world.item.CreativeModeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;

@Mod(VinylDeck.MODID)
public class VinylDeck {
    public static final String MODID = "vinyldeck";

    public VinylDeck(IEventBus modBus) {
        ModItems.ITEMS.register(modBus);
        modBus.addListener(VinylDeck::addCreative);
    }

    private static void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.PORTABLE_PLAYER.get());
        }
    }
}
