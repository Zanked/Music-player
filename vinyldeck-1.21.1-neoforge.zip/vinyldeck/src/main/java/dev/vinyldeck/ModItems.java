package dev.vinyldeck;

import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(VinylDeck.MODID);

    public static final DeferredItem<PortablePlayerItem> PORTABLE_PLAYER =
            ITEMS.registerItem("portable_player", PortablePlayerItem::new, new Item.Properties().stacksTo(1));

    private ModItems() {}
}
